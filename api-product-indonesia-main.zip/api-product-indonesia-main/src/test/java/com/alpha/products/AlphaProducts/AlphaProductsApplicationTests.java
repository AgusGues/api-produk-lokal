package com.alpha.products.AlphaProducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphaProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
