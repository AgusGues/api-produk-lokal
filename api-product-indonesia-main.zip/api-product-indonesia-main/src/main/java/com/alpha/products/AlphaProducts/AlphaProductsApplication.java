package com.alpha.products.AlphaProducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class AlphaProductsApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(AlphaProductsApplication.class, args);
	}

}
